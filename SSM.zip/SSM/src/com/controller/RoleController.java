package com.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.entity.Role;
import com.service.RoleService;

@Controller
@ContextConfiguration(locations ={"classpath:applicationContext.xml"})
public class RoleController {
	
	private boolean status = false;
	@Autowired
	RoleService roleService;
	
	@RequestMapping(value= {"/login","/"})
	public String loginpage() {
		return "/login";
	}
	
	@RequestMapping(value="/logincheck",method = RequestMethod.POST)
	public ModelAndView loginSystem(String role_name,String role_pwd) throws Exception{
		Role role = roleService.loginChecked(role_name);
		ModelAndView mav = new ModelAndView();
		if(role!=null && role_pwd.equals(role.getRole_pwd())) {
			status = true;
			mav.setViewName("/main");
			mav.addObject("role_name", role_name);
			return mav;
		}else {
			mav.setViewName("/login");
			return mav;
		}
	}
	
	@RequestMapping(value= "/main")
	public String loadMainPage() {
		return "/login";
	}
	/*
	 * 获取管理员人员信息
	 */
	@RequestMapping(value="/getRoleList")
	@ResponseBody
	public Map<String, Object> showAllRoles(@RequestParam Map<String, String> map) throws Exception {
	    Map<String, Object> map1 = new HashMap<>();
	    List<Map<String, String>> list = new ArrayList<>();
	    List<Role> roles = roleService.selectAllRoles();
	    Role role = null;
	    for (int i = 0; i < roles.size(); i++) {
	    	role = roles.get(i);
	        map = new HashMap<>();
	        map.put("role_id", String.valueOf(role.getRole_id()));
	        map.put("role_name", role.getRole_name());
	        map.put("role_pwd",role.getRole_pwd());
	        map.put("role_identity", role.getRole_identity());
	        map.put("role_status", role.getRole_status());
	        list.add(map);
	    }
	    map1.put("rows", list);
	    map1.put("total", roles.size());
	    return map1;
	}
}
